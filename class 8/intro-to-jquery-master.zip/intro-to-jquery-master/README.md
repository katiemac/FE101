Sample code used for New York Code & Design Academy's introductory jQuery lesson.

Code adapted from https://developer.apple.com/library/safari/samplecode/TicTacToe
